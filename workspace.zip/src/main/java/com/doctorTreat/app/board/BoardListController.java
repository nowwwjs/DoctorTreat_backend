package com.doctorTreat.app.board;

public class BoardListController {

}
