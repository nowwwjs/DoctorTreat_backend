package com.doctorTreat.app.board;

public class BoardDetailController {

}
