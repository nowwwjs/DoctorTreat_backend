package com.doctorTreat.app.board;

public class BoardWriteController {

}
