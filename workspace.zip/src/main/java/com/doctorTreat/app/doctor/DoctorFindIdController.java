package com.doctorTreat.app.doctor;

public class DoctorFindIdController {

}
