package com.doctorTreat.app.member;

public class MemberLoginController {

}
