package com.doctorTreat.app.member;

public class MemberFindIdController {

}
