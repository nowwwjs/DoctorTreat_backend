package com.doctorTreat.app.member;

public class MemberJoinController {

}
