package com.doctorTreat.app.doctorMypage;

public class DoctorInfoController {

}
