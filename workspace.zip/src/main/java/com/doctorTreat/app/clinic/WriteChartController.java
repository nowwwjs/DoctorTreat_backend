package com.doctorTreat.app.clinic;

public class WriteChartController {

}
