package com.doctorTreat.app;

public interface Execute {

}
